Le but de notre programme consiste à créer un jeu de bataille navale. 
Tout d'abord, Yvan a procédé à la créeation de l'interface graphique dans laquelle il se trouve la fonction jouer à 2 ( deux personnes peuvent s'affronter ) et aussi il existe aussi la fonction jouer contre l'ordinateur ( ou un joueur peut affronter une intelligence artificielle ). Il a aussi créer une fenêtre "règles afin qu'on puisse comprendre les règles de la bataille navale. Il a aussi rassemblé tous les programmes dans un seul fichier python. 
Ensuite Justin a 
